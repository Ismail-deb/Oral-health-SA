import React, { useState } from 'react';
import type { Page } from '../types';
import { LogoIcon, UserIcon } from './icons';
import { useTheme } from '../contexts/ThemeContext';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';

interface HeaderProps {
  onNavigate: (page: Page) => void;
  currentPage: Page;
}

const NavLink: React.FC<{
  page: Page;
  currentPage: Page;
  onNavigate: (page: Page) => void;
  children: React.ReactNode;
  className?: string;
}> = ({ page, currentPage, onNavigate, children, className }) => {
  const isActive = page === currentPage;
  return (
    <a
      onClick={() => onNavigate(page)}
      className={`font-medium transition-colors cursor-pointer ${className} ${
        isActive
          ? 'text-primary font-semibold'
          : 'text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-primary'
      }`}
    >
      {children}
    </a>
  );
};

export const Header: React.FC<HeaderProps> = ({ onNavigate, currentPage }) => {
  const { theme, toggleTheme } = useTheme();
  const { currentUser, logout } = useAuth();
  const { t } = useLanguage();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleMobileNav = (page: Page) => {
    onNavigate(page);
    setIsMenuOpen(false);
  };
  
  const navItems = [
    { page: 'home' as Page, label: t('header.home') },
    { page: 'learn' as Page, label: t('header.learn') },
    { page: 'directory' as Page, label: t('header.find_dentist') },
    { page: 'tracker' as Page, label: t('header.symptom_tracker') },
    { page: 'community' as Page, label: t('header.community') },
    { page: 'chat' as Page, label: t('header.ai_assistant') },
  ];
  
  const handleLogout = () => {
      if (isMenuOpen) setIsMenuOpen(false);
      logout();
  }
  
  const handleLoginNav = () => {
      if (isMenuOpen) setIsMenuOpen(false);
      onNavigate('auth');
  }

  return (
    <>
      <header className="sticky top-0 z-50 flex items-center justify-between whitespace-nowrap border-b border-gray-200/50 dark:border-gray-700/50 bg-background-light/80 dark:bg-background-dark/80 backdrop-blur-sm px-4 md:px-10 py-3 shrink-0">
        <div className="flex items-center gap-3 text-gray-900 dark:text-white cursor-pointer" onClick={() => onNavigate('home')}>
          <LogoIcon className="h-8 w-8 text-primary" />
          <h2 className="text-xl font-bold">DentiBuddy</h2>
        </div>
        <nav className="hidden md:flex flex-1 justify-end items-center gap-6">
          {navItems.map(item => (
            <NavLink key={item.page} page={item.page} currentPage={currentPage} onNavigate={onNavigate} className="text-sm">
              {item.label}
            </NavLink>
          ))}
          <button
            onClick={toggleTheme}
            className="p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
            aria-label="Toggle dark mode"
          >
            <span className="material-symbols-outlined">
              {theme === 'dark' ? 'light_mode' : 'dark_mode'}
            </span>
          </button>
          
          {!currentUser ? (
             <button onClick={() => onNavigate('auth')} className="bg-primary text-white text-sm font-bold px-4 py-2 rounded-lg hover:bg-primary/90 transition-colors">
              {t('header.login_signup')}
            </button>
          ) : (
             <>
                <button onClick={() => onNavigate('profile')} className="size-10 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-500 dark:text-slate-400" aria-label={t('header.my_profile')}>
                    <UserIcon className="w-6 h-6" />
                </button>
                <button onClick={handleLogout} className="p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors" aria-label={t('header.logout')}>
                    <span className="material-symbols-outlined">logout</span>
                </button>
             </>
          )}

        </nav>
        <button 
          className="md:hidden text-gray-800 dark:text-gray-200 z-[60]"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-expanded={isMenuOpen}
          aria-controls="mobile-menu"
        >
          <span className="material-symbols-outlined">
            {isMenuOpen ? 'close' : 'menu'}
          </span>
        </button>
      </header>

      {/* Mobile Menu Overlay */}
      <div 
        id="mobile-menu"
        className={`fixed inset-0 z-40 h-screen md:hidden transition-opacity duration-300 ${isMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
        onClick={() => setIsMenuOpen(false)}
      >
        <div className="absolute inset-0 bg-black/30"></div>
        <div 
          className={`absolute right-0 top-0 h-full w-4/5 max-w-sm bg-background-light dark:bg-background-dark shadow-xl p-6 pt-24 transition-transform duration-300 ease-in-out ${isMenuOpen ? 'translate-x-0' : 'translate-x-full'}`}
          onClick={e => e.stopPropagation()}
        >
          <nav className="flex flex-col h-full">
            <div className="flex-grow space-y-2">
              {navItems.map(item => (
                  <NavLink key={item.page} page={item.page} currentPage={currentPage} onNavigate={handleMobileNav} className="block text-xl py-3">
                    {item.label}
                  </NavLink>
              ))}
            </div>
            
            <div className="flex-shrink-0 border-t border-gray-200/50 dark:border-gray-700/50 pt-6 space-y-4">
              {!currentUser ? (
                <a onClick={handleLoginNav} className="flex items-center gap-4 text-xl font-medium text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-primary cursor-pointer">
                    <span className="material-symbols-outlined ml-2">login</span>
                    <span>{t('header.login_signup')}</span>
                </a>
              ) : (
                <>
                  <a onClick={() => handleMobileNav('profile')} className="flex items-center gap-4 text-xl font-medium text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-primary cursor-pointer">
                      <div className="size-10 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-500 dark:text-slate-400">
                          <UserIcon className="w-6 h-6" />
                      </div>
                      <span>{t('header.my_profile')}</span>
                  </a>
                  <a onClick={handleLogout} className="flex items-center gap-4 text-xl font-medium text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-primary cursor-pointer">
                      <span className="material-symbols-outlined ml-2">logout</span>
                      <span>{t('header.logout')}</span>
                  </a>
                </>
              )}

              <div className="flex items-center justify-between">
                  <span className="text-xl font-medium text-gray-600 dark:text-gray-300">Theme</span>
                  <button
                      onClick={toggleTheme}
                      className="p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
                      aria-label="Toggle dark mode"
                  >
                      <span className="material-symbols-outlined">
                          {theme === 'dark' ? 'light_mode' : 'dark_mode'}
                      </span>
                  </button>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </>
  );
};