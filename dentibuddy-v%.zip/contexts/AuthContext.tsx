import React, { createContext, useState, useEffect, useContext, ReactNode, useCallback } from 'react';
import { getUserById } from '../services/dbService';
import type { User } from '../types';

interface AuthContextType {
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const checkLoggedInUser = async () => {
      try {
        const userId = localStorage.getItem('currentUserId');
        if (userId) {
          const user = await getUserById(userId);
          setCurrentUser(user);
        }
      } catch (error) {
        console.error("Failed to check for logged in user", error);
        localStorage.removeItem('currentUserId');
      } finally {
        setIsLoading(false);
      }
    };
    checkLoggedInUser();
  }, []);

  const handleSetCurrentUser = useCallback((user: User | null) => {
    setCurrentUser(user);
    if (user) {
      localStorage.setItem('currentUserId', user.id);
    } else {
      localStorage.removeItem('currentUserId');
    }
  }, []);

  const logout = useCallback(() => {
    handleSetCurrentUser(null);
  }, [handleSetCurrentUser]);

  return (
    <AuthContext.Provider value={{ currentUser, setCurrentUser: handleSetCurrentUser, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};