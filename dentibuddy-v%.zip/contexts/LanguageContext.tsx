import React, { createContext, useState, useEffect, useContext, ReactNode, useCallback } from 'react';
import type { Language } from '../types';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isTranslationsLoading: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    if (typeof window !== 'undefined') {
      const savedLang = localStorage.getItem('language') as Language;
      if (savedLang && ['en', 'af', 'xh', 'zu'].includes(savedLang)) {
        return savedLang;
      }
    }
    return 'en';
  });

  const [translations, setTranslations] = useState<Record<Language, any> | null>(null);
  const [isTranslationsLoading, setIsTranslationsLoading] = useState(true);

  useEffect(() => {
    const loadTranslations = async () => {
      setIsTranslationsLoading(true);
      try {
        const [en, af, xh, zu] = await Promise.all([
          fetch('./i18n/locales/en.json').then(res => res.json()),
          fetch('./i18n/locales/af.json').then(res => res.json()),
          fetch('./i18n/locales/xh.json').then(res => res.json()),
          fetch('./i18n/locales/zu.json').then(res => res.json()),
        ]);
        setTranslations({ en, af, xh, zu });
      } catch (error) {
        console.error("Failed to load translations:", error);
      } finally {
        setIsTranslationsLoading(false);
      }
    };
    loadTranslations();
  }, []);

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang);
    try {
      localStorage.setItem('language', lang);
    } catch (error) {
      console.error("Failed to save language to local storage", error);
    }
  }, []);

  const t = useCallback((key: string): string => {
    if (!translations) {
      return key; // Return the key itself if translations are not loaded
    }
    const keys = key.split('.');
    let result: any;
    try {
      result = translations[language] || translations['en']; // Fallback to English if current lang is missing
      for (const k of keys) {
        if (result === undefined) break;
        result = result[k];
      }
      return result || key;
    } catch (error) {
      return key;
    }
  }, [language, translations]);

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isTranslationsLoading }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
