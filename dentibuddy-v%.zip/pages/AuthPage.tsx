import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { LogoIcon } from '../components/icons';
import { createUser, getUserByEmail } from '../services/dbService';
import type { User } from '../types';
import { useLanguage } from '../contexts/LanguageContext';

type AuthMode = 'login' | 'signup';

interface AuthPageProps {
    onNavigateBack: () => void;
}

const AuthPage: React.FC<AuthPageProps> = ({ onNavigateBack }) => {
    const { setCurrentUser } = useAuth();
    const { t } = useLanguage();
    const [mode, setMode] = useState<AuthMode>('login');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
        event.preventDefault();
        setIsLoading(true);
        setError(null);

        const formData = new FormData(event.currentTarget);
        const email = formData.get('email') as string;
        const password = formData.get('password') as string;

        try {
            if (mode === 'login') {
                const user = await getUserByEmail(email);
                if (user && user.password === password) {
                    setCurrentUser(user);
                } else {
                    setError(t('auth.error_invalid_credentials'));
                }
            } else { // signup
                const name = formData.get('name') as string;
                const confirmPassword = formData.get('confirmPassword') as string;

                if (password !== confirmPassword) {
                    setError(t('auth.error_password_mismatch'));
                    setIsLoading(false);
                    return;
                }

                const existingUser = await getUserByEmail(email);
                if (existingUser) {
                    setError(t('auth.error_email_exists'));
                } else {
                    const newUser: User = {
                        id: `user-${Date.now()}`,
                        name,
                        email,
                        password
                    };
                    await createUser(newUser);
                    setCurrentUser(newUser);
                }
            }
        } catch (err) {
            console.error(err);
            setError(t('auth.error_unexpected'));
        } finally {
            setIsLoading(false);
        }
    };
    
    const InputField: React.FC<{ id: string; name: string; type: string; icon: string; required?: boolean; placeholder: string; }> = ({ id, name, type, icon, required = true, placeholder }) => (
        <div className="relative">
            <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                {icon}
            </span>
            <input 
                id={id} 
                name={name} 
                type={type} 
                required={required}
                className="w-full rounded-lg border border-gray-300 bg-transparent py-3 pl-10 pr-4 text-gray-800 placeholder-gray-400 transition-colors focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 dark:border-gray-600 dark:text-gray-200"
                placeholder={placeholder}
            />
        </div>
    );

    return (
        <div className="grid min-h-screen w-full grid-cols-1 md:grid-cols-2">
            <div className="relative flex flex-col items-center justify-center bg-background-light p-6 dark:bg-background-dark sm:p-10">
                <button onClick={onNavigateBack} className="absolute top-6 left-6 flex items-center gap-2 rounded-full bg-white/50 px-4 py-2 text-sm font-medium text-gray-600 backdrop-blur-sm transition-colors hover:bg-white/80 dark:bg-slate-800/50 dark:text-gray-300 dark:hover:bg-slate-800/80 z-10">
                    <span className="material-symbols-outlined">arrow_back</span>
                    <span>{t('auth.back')}</span>
                </button>
                <div className="w-full max-w-md animate-fade-in">
                    <div className="mb-8 text-center md:text-left">
                        <div className="inline-flex items-center gap-3">
                            <LogoIcon className="h-10 w-10 text-primary" />
                            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">DentiBuddy</h1>
                        </div>
                        <h2 className="mt-6 text-3xl font-extrabold text-gray-900 dark:text-white sm:text-4xl">
                            {mode === 'login' ? t('auth.welcome') : t('auth.create_account')}
                        </h2>
                        <p className="mt-2 text-base text-gray-600 dark:text-gray-400">
                            {mode === 'login' ? t('auth.no_account') : t('auth.has_account')}
                            <button
                                onClick={() => {
                                    setMode(mode === 'login' ? 'signup' : 'login');
                                    setError(null);
                                }}
                                className="ml-2 font-semibold text-primary transition-all hover:underline"
                            >
                                {mode === 'login' ? t('auth.signup') : t('auth.signin')}
                            </button>
                        </p>
                    </div>

                    <form key={mode} onSubmit={handleSubmit} className="space-y-5 animate-fade-in">
                        {mode === 'signup' && (
                            <InputField id="name" name="name" type="text" icon="person" placeholder={t('auth.name')} />
                        )}
                        <InputField id="email" name="email" type="email" icon="mail" placeholder={t('auth.email')} />
                        <InputField id="password" name="password" type="password" icon="lock" placeholder={t('auth.password')} />
                        {mode === 'signup' && (
                             <InputField id="confirmPassword" name="confirmPassword" type="password" icon="lock" placeholder={t('auth.confirm_password')} />
                        )}

                        {error && <p className="text-sm font-medium text-red-500">{error}</p>}
                        
                        <button 
                            type="submit" 
                            disabled={isLoading} 
                            className="w-full rounded-lg bg-primary py-3.5 text-base font-bold text-white shadow-lg shadow-primary/30 transition-all hover:bg-primary/90 hover:shadow-xl hover:shadow-primary/40 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 dark:focus:ring-offset-background-dark disabled:opacity-60 disabled:shadow-none"
                        >
                            {isLoading ? t('auth.processing') : (mode === 'login' ? t('auth.submit_signin') : t('auth.submit_signup'))}
                        </button>
                    </form>
                    
                     <div className="mt-8 flex items-start gap-3 rounded-lg bg-blue-50 p-4 dark:bg-blue-900/20">
                        <span className="material-symbols-outlined mt-1 text-blue-600 dark:text-blue-400">info</span>
                        <p className="text-sm text-blue-800 dark:text-blue-300">
                           <strong>{t('auth.disclaimer_title')}</strong> {t('auth.disclaimer_text')}
                        </p>
                    </div>

                </div>
            </div>
            <div className="relative hidden items-center justify-center md:flex">
                <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: 'url(https://images.pexels.com/photos/3845763/pexels-photo-3845763.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2)' }}></div>
                <div className="absolute inset-0 bg-gradient-to-br from-primary/70 to-teal-500/70"></div>
                <div className="relative z-10 max-w-md text-center text-white">
                    <h2 className="text-4xl font-bold">{t('auth.hero_title')}</h2>
                    <p className="mt-4 text-lg opacity-90">{t('auth.hero_subtitle')}</p>
                </div>
            </div>
        </div>
    );
};

export default AuthPage;