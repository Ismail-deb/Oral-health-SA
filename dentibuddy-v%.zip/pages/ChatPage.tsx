import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { Page, ChatMessage, ChatSession } from '../types';
import { createChat, sendMessage, translateText } from '../services/geminiService';
import { Header } from '../components/Header';
import { UserIcon } from '../components/icons';
import { getValue, getAllChatSessions, saveChatSession, deleteChatSession } from '../services/dbService';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

interface ChatAreaProps {
  messages: ChatMessage[];
  isLoading: boolean;
  aiAvatar: string;
  t: (key: string) => string;
  messagesEndRef: React.RefObject<HTMLDivElement>;
  quickPrompts: string[];
  handleSend: (prompt?: string) => void;
  input: string;
  setInput: (value: string) => void;
  handleMicClick: () => void;
  isListening: boolean;
  isTranslating: boolean;
  isSpeechRecognitionSupported: boolean;
}

const ChatArea: React.FC<ChatAreaProps> = ({
  messages, isLoading, aiAvatar, t, messagesEndRef,
  quickPrompts, handleSend, input, setInput,
  handleMicClick, isListening, isTranslating, isSpeechRecognitionSupported
}) => (
    <div className="w-full max-w-4xl flex-grow flex flex-col h-full p-4">
      <div className="flex-grow space-y-6 overflow-y-auto p-4 md:p-6 bg-white dark:bg-background-dark/50 rounded-xl border border-gray-200/50 dark:border-gray-800/50">
        {messages.map((msg, index) => (
          <div key={index} className={`flex gap-3 items-start ${msg.role === 'user' ? 'justify-end' : ''}`}>
            {msg.role === 'model' && (
              <div className="w-8 h-8 rounded-full bg-cover bg-center shrink-0" style={{ backgroundImage: `url("${aiAvatar}")` }}></div>
            )}
            <div className={`flex flex-col gap-1 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
              <span className="text-sm font-medium text-gray-500 dark:text-gray-400">{msg.role === 'model' ? t('chat.title') : t('chat.you')}</span>
              <div className={`${msg.role === 'model' ? 'bg-background-light dark:bg-gray-800 rounded-tl-none' : 'bg-primary/20 dark:bg-primary/30 rounded-tr-none'} p-3 rounded-lg max-w-lg`}>
                <p className="text-gray-800 dark:text-gray-200 whitespace-pre-wrap">{msg.text}</p>
              </div>
            </div>
             {msg.role === 'user' && (
              <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-500 dark:text-slate-400 shrink-0">
                <UserIcon className="w-5 h-5" />
              </div>
            )}
          </div>
        ))}
        {isLoading && (
          <div className="flex gap-3 items-start animate-fade-in">
              <div className="w-8 h-8 rounded-full bg-cover bg-center" style={{ backgroundImage: `url("${aiAvatar}")` }}></div>
              <div className="flex flex-col gap-1 items-start">
                <span className="text-sm font-medium text-gray-500 dark:text-gray-400">{t('chat.title')}</span>
                <div className="bg-background-light dark:bg-gray-800 p-3 rounded-lg rounded-tl-none">
                    <div className="flex items-end gap-1.5 h-5 text-primary">
                       <div className="w-2 h-2 bg-current rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                       <div className="w-2 h-2 bg-current rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                       <div className="w-2 h-2 bg-current rounded-full animate-bounce"></div>
                    </div>
                </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      
      <div className="pt-4 shrink-0">
         {messages.length <= 1 && (
         <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mb-4">
            {quickPrompts.map(prompt => (
                 <button key={prompt} onClick={() => handleSend(prompt)} className="text-left text-sm p-3 bg-white dark:bg-background-dark/50 border border-gray-200/50 dark:border-gray-800/50 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 disabled:opacity-50" disabled={isLoading}>
                    {prompt}
                 </button>
            ))}
        </div>)}
        <div className="relative">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            disabled={isLoading || isTranslating}
            className="w-full h-14 md:h-16 p-4 pr-28 text-base bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-primary focus:outline-none resize-none"
            placeholder={isListening ? t('chat.listening') : (isTranslating ? t('chat.translating') : t('chat.placeholder'))}
          />
          <div className="absolute top-1/2 right-3 transform -translate-y-1/2 flex items-center gap-2">
            <button
                type="button"
                onClick={handleMicClick}
                disabled={!isSpeechRecognitionSupported || isLoading}
                className={`p-2 rounded-full transition-colors ${
                isListening
                    ? 'bg-red-500 text-white animate-pulse'
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
                } disabled:opacity-50 disabled:cursor-not-allowed`}
                aria-label={isListening ? 'Stop recording' : 'Start recording'}
            >
                <span className="material-symbols-outlined">{isTranslating ? 'hourglass_top' : 'mic'}</span>
            </button>
            <button onClick={() => handleSend()} disabled={isLoading || isTranslating || !input.trim()} className="p-2 rounded-full text-white bg-primary hover:bg-primary/90 disabled:bg-primary/50">
              <span className="material-symbols-outlined">send</span>
            </button>
          </div>
        </div>
      </div>
    </div>
);


const GuestSidebar: React.FC<{ onNavigate: (page: Page) => void; t: (key: string) => string; }> = ({ onNavigate, t }) => (
    <div className="w-full md:w-80 h-full flex flex-col p-4">
        <div className="flex-grow flex flex-col items-center justify-center text-center bg-gray-100 dark:bg-gray-800/50 rounded-lg p-4">
            <span className="material-symbols-outlined text-5xl text-primary mb-4">
                history
            </span>
            <h3 className="font-bold text-lg text-gray-800 dark:text-gray-200">{t('chat.history_info')}</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                <button onClick={() => onNavigate('auth')} className="text-primary font-semibold hover:underline">
                    {t('chat.history_login_prompt')}
                </button>
                {' '}{t('chat.history_login_suffix')}
            </p>
        </div>
    </div>
);

interface ChatPageProps {
  onNavigate: (page: Page) => void;
}

const ChatPage: React.FC<ChatPageProps> = ({ onNavigate }) => {
  const { currentUser } = useAuth();
  const { language, t } = useLanguage();
  
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [chatHistory, setChatHistory] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [sessionToDelete, setSessionToDelete] = useState<string | null>(null);

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isTranslating, setIsTranslating] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [aiAvatar, setAiAvatar] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isSpeechRecognitionSupported, setIsSpeechRecognitionSupported] = useState(false);
  
  const recognitionInstanceRef = useRef<any | null>(null);
  const manualStopRef = useRef(false);
  const baseInputRef = useRef<string>('');
  const englishTranscriptRef = useRef<string>('');
  const debounceTimeoutRef = useRef<number | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const prevUserRef = useRef(currentUser);

  // Initialize with a welcome message
  useEffect(() => {
    setMessages([{ role: 'model', text: t('chat.initial_message') }]);
  }, [t]);

  // Reset chat state on logout for privacy
  useEffect(() => {
    if (prevUserRef.current && !currentUser) { // User just logged out
      setMessages([{ role: 'model', text: t('chat.initial_message') }]);
      setChatHistory([]);
      setActiveSessionId(null);
    }
    prevUserRef.current = currentUser;
  }, [currentUser, t]);

  // Load user's chat history on login
  useEffect(() => {
    if (currentUser) {
      const loadHistory = async () => {
        const history = await getAllChatSessions(currentUser.id);
        setChatHistory(history.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
      };
      loadHistory();
    }
  }, [currentUser]);

  // Update displayed messages when active session changes
  useEffect(() => {
    if (activeSessionId && currentUser) {
      const activeSession = chatHistory.find(s => s.id === activeSessionId);
      setMessages(activeSession ? activeSession.messages : [{ role: 'model', text: t('chat.initial_message') }]);
    } else {
      setMessages([{ role: 'model', text: t('chat.initial_message') }]);
    }
  }, [activeSessionId, chatHistory, t, currentUser]);

  // Load AI avatar
  useEffect(() => {
    const loadAvatars = async () => {
      const storedAiAvatar = await getValue('aiAssistantAvatar');
      if (storedAiAvatar) setAiAvatar(storedAiAvatar);
    };
    loadAvatars();
  }, []);
  
  // Setup speech recognition API availability and update state to trigger re-render
  useEffect(() => {
    const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
    setIsSpeechRecognitionSupported(!!SpeechRecognitionAPI);
    if (!SpeechRecognitionAPI) {
        console.warn('Speech Recognition not supported by this browser.');
    }
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);

  const handleSend = useCallback(async (prompt?: string) => {
    const userMessageText = prompt || input;
    if (!userMessageText.trim()) return;

    const userMessage: ChatMessage = { role: 'user', text: userMessageText };
    const currentMessages = [...messages, userMessage];
    setMessages(currentMessages);
    setInput('');
    setIsLoading(true);

    let sessionForSaving: ChatSession | undefined;

    if (currentUser) {
        let sessionIdToUpdate: string;
        if (activeSessionId) {
            sessionIdToUpdate = activeSessionId;
            sessionForSaving = chatHistory.find(s => s.id === sessionIdToUpdate);
            if (sessionForSaving) {
                sessionForSaving = { ...sessionForSaving, messages: currentMessages };
            }
        } else {
            sessionForSaving = {
                id: `session-${Date.now()}`,
                userId: currentUser.id,
                title: userMessageText.substring(0, 40) + (userMessageText.length > 40 ? '...' : ''),
                createdAt: new Date().toISOString(),
                messages: currentMessages,
            };
            sessionIdToUpdate = sessionForSaving.id;
        }
        
        if (sessionForSaving) {
            setActiveSessionId(sessionIdToUpdate);
            setChatHistory(prev => {
                const existing = prev.find(s => s.id === sessionIdToUpdate);
                if (existing) {
                    return prev.map(s => s.id === sessionIdToUpdate ? sessionForSaving! : s);
                }
                return [sessionForSaving!, ...prev];
            });
            await saveChatSession(sessionForSaving);
        }
    }
    
    try {
        const historyForModel = currentMessages.slice(1);
        const chat = createChat(language, historyForModel);
        const response = await sendMessage(chat, userMessageText);
        const modelMessage: ChatMessage = { role: 'model', text: response.text };
        
        const finalMessages = [...currentMessages, modelMessage];
        setMessages(finalMessages);

        if (currentUser && sessionForSaving) {
            const finalSession = { ...sessionForSaving, messages: finalMessages };
            await saveChatSession(finalSession);
            setChatHistory(prev => prev.map(s => s.id === finalSession.id ? finalSession : s));
        }

    } catch (error) {
        const errorMessage = error instanceof Error ? error.message : t('chat.error_message');
        const errorModelMessage = { role: 'model' as const, text: errorMessage };
        const finalMessages = [...currentMessages, errorModelMessage];
        setMessages(finalMessages);
        
        if (currentUser && sessionForSaving) {
            const finalSession = { ...sessionForSaving, messages: finalMessages };
            await saveChatSession(finalSession);
            setChatHistory(prev => prev.map(s => s.id === finalSession.id ? finalSession : s));
        }
    } finally {
        setIsLoading(false);
    }
  }, [input, currentUser, messages, activeSessionId, chatHistory, language, t]);
  
  const handleNewChat = () => setActiveSessionId(null);

  const handleConfirmDelete = async () => {
    if (!sessionToDelete || !currentUser) return;
    await deleteChatSession(sessionToDelete);
    setChatHistory(prev => prev.filter(s => s.id !== sessionToDelete));
    if (activeSessionId === sessionToDelete) {
      handleNewChat();
    }
    setSessionToDelete(null);
  };

 const handleMicClick = useCallback(() => {
    const SpeechRecognitionAPI = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognitionAPI) {
        alert("Speech recognition is not supported by your browser.");
        return;
    }

    const recognition = recognitionInstanceRef.current;

    // --- Stop Listening ---
    if (isListening && recognition) {
        manualStopRef.current = true;
        recognition.stop();
        return;
    }

    // --- Start Listening ---
    manualStopRef.current = false;
    const newRecognition = new SpeechRecognitionAPI();
    recognitionInstanceRef.current = newRecognition;

    baseInputRef.current = input; 
    englishTranscriptRef.current = '';

    newRecognition.continuous = true;
    newRecognition.interimResults = true;
    newRecognition.lang = 'en-ZA';

    newRecognition.onstart = () => setIsListening(true);
    
    const performTranslation = async (textToTranslate: string) => {
        if (language === 'en' || !textToTranslate.trim()) return;
        setIsTranslating(true);
        try {
            const translatedPart = await translateText(textToTranslate, 'en', language);
            const newText = (baseInputRef.current + (baseInputRef.current ? ' ' : '') + translatedPart).trim();
            setInput(newText);
        } catch (error) {
            console.error('Translation failed:', error);
        } finally {
            setIsTranslating(false);
        }
    };

    newRecognition.onresult = (event: any) => {
        let liveTranscript = '';
        for (let i = 0; i < event.results.length; i++) {
            liveTranscript += event.results[i][0].transcript;
        }
        englishTranscriptRef.current = liveTranscript;
        
        const newEnglishText = (baseInputRef.current + (baseInputRef.current ? ' ' : '') + liveTranscript).trim();
        setInput(newEnglishText); 

        if (language !== 'en') {
            if (debounceTimeoutRef.current) clearTimeout(debounceTimeoutRef.current);
            debounceTimeoutRef.current = window.setTimeout(() => {
                performTranslation(englishTranscriptRef.current);
            }, 1000); 
        }
    };

    newRecognition.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error, event.message);
        manualStopRef.current = true; // This will trigger cleanup in onend
        if (event.error === 'not-allowed') {
            alert("Microphone access was denied. Please allow microphone access in your browser settings to use this feature.");
        }
        // onend will be called automatically after an error.
    };

    newRecognition.onend = () => {
        if (manualStopRef.current) {
            // This was a manual stop or an error, so clean everything up.
            setIsListening(false);
            recognitionInstanceRef.current = null;
            if (debounceTimeoutRef.current) clearTimeout(debounceTimeoutRef.current);
            performTranslation(englishTranscriptRef.current);
        } else {
            // This was a browser timeout. Restart to continue listening.
            if (recognitionInstanceRef.current) {
                try {
                    recognitionInstanceRef.current.start();
                } catch(e) {
                    console.error("Could not restart speech recognition", e);
                    setIsListening(false);
                    recognitionInstanceRef.current = null;
                }
            }
        }
    };

    newRecognition.start();
}, [isListening, language, input]);


  const quickPrompts = [
    t('chat.quick_prompt_1'),
    t('chat.quick_prompt_2'),
    t('chat.quick_prompt_3'),
  ];
  
  const ConfirmationModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void;
  }> = ({ isOpen, onClose, onConfirm }) => {
    if (!isOpen) return null;

    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm animate-fade-in" onClick={onClose}>
        <div className="relative w-full max-w-sm transform-gpu rounded-xl bg-background-light p-6 text-center shadow-2xl transition-all duration-300 dark:bg-background-dark" onClick={e => e.stopPropagation()}>
          <span className="material-symbols-outlined mb-4 text-6xl text-red-500">
            warning
          </span>
          <h2 className="text-xl font-bold">{t('chat.delete_confirm_title')}</h2>
          <p className="mt-2 text-gray-600 dark:text-gray-400">{t('chat.delete_confirm_message')}</p>
          <div className="mt-6 flex justify-center gap-4">
            <button onClick={onClose} className="w-full rounded-lg bg-gray-200 py-2.5 text-base font-bold text-gray-800 hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600">
              {t('community.modal_cancel')}
            </button>
            <button onClick={onConfirm} className="w-full rounded-lg bg-red-600 py-2.5 text-base font-bold text-white hover:bg-red-500">
              {t('chat.delete_button')}
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-screen bg-background-light dark:bg-background-dark">
      <Header onNavigate={onNavigate} currentPage="chat" />
      <main className="flex-grow flex overflow-hidden">
        {currentUser ? (
          <>
            <aside className={`
                transition-all duration-300 ease-in-out 
                bg-white/50 dark:bg-background-dark/50 
                border-r border-gray-200 dark:border-gray-800 
                flex-shrink-0
                ${isSidebarOpen ? 'w-full md:w-80' : 'w-0 border-r-0'}
            `}>
                <div className={`
                    w-full md:w-80 h-full flex flex-col p-4 transition-opacity duration-300
                    ${isSidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}
                `}>
                    <button onClick={handleNewChat} className="w-full flex items-center justify-center gap-2 bg-primary text-white font-bold py-2.5 px-4 rounded-lg hover:bg-primary/90 transition-colors mb-4">
                      <span className="material-symbols-outlined">add</span>
                      <span className="truncate">{t('chat.new_conversation')}</span>
                    </button>
                    <div className="flex-grow overflow-y-auto space-y-2">
                      {chatHistory.map(session => (
                        <div key={session.id} onClick={() => setActiveSessionId(session.id)} className={`group relative p-3 rounded-lg cursor-pointer ${activeSessionId === session.id ? 'bg-primary/10 text-primary' : 'hover:bg-gray-200/50 dark:hover:bg-gray-800/50'}`}>
                          <p className="font-semibold text-sm truncate">{session.title}</p>
                          <p className="text-xs opacity-60 truncate">{session.messages[1]?.text || '...'}</p>
                          <button onClick={(e) => { e.stopPropagation(); setSessionToDelete(session.id); }} className="absolute top-1/2 -translate-y-1/2 right-2 p-1.5 rounded-full text-red-500/80 bg-inherit hover:bg-red-100 dark:hover:bg-red-900/50 opacity-0 group-hover:opacity-100 transition-opacity">
                            <span className="material-symbols-outlined !text-sm">delete</span>
                          </button>
                        </div>
                      ))}
                    </div>
                </div>
            </aside>
            <div className={`flex-grow flex justify-center overflow-hidden relative ${isSidebarOpen ? 'hidden md:flex' : 'flex'}`}>
              <button
                  onClick={() => setIsSidebarOpen(!isSidebarOpen)}
                  className="absolute top-1/2 -translate-y-1/2 z-20 bg-background-light dark:bg-background-dark border border-gray-300 dark:border-gray-700 rounded-full p-1.5 hover:bg-gray-200 dark:hover:bg-gray-700 transition-all text-gray-600 dark:text-gray-300"
                  style={{ left: isSidebarOpen ? '-18px' : '8px' }}
                  aria-label={isSidebarOpen ? t('chat.collapse_sidebar') : t('chat.expand_sidebar')}
              >
                  <span className="material-symbols-outlined !text-xl transition-transform duration-300" style={{ transform: isSidebarOpen ? 'rotate(0deg)' : 'rotate(180deg)' }}>
                      chevron_left
                  </span>
              </button>
              <ChatArea 
                messages={messages}
                isLoading={isLoading}
                aiAvatar={aiAvatar}
                t={t}
                messagesEndRef={messagesEndRef}
                quickPrompts={quickPrompts}
                handleSend={handleSend}
                input={input}
                setInput={setInput}
                handleMicClick={handleMicClick}
                isListening={isListening}
                isTranslating={isTranslating}
                isSpeechRecognitionSupported={isSpeechRecognitionSupported}
              />
            </div>
          </>
        ) : (
          <>
            <aside className="hidden md:flex w-80 bg-white/50 dark:bg-background-dark/50 border-r border-gray-200 dark:border-gray-800 flex-shrink-0">
                <GuestSidebar onNavigate={onNavigate} t={t} />
            </aside>
            <div className="flex-grow flex justify-center overflow-hidden relative">
              <ChatArea 
                messages={messages}
                isLoading={isLoading}
                aiAvatar={aiAvatar}
                t={t}
                messagesEndRef={messagesEndRef}
                quickPrompts={quickPrompts}
                handleSend={handleSend}
                input={input}
                setInput={setInput}
                handleMicClick={handleMicClick}
                isListening={isListening}
                isTranslating={isTranslating}
                isSpeechRecognitionSupported={isSpeechRecognitionSupported}
              />
            </div>
          </>
        )}
      </main>
       <ConfirmationModal
        isOpen={!!sessionToDelete}
        onClose={() => setSessionToDelete(null)}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
};

export default ChatPage;