import React, { useState, useCallback, useEffect, useMemo } from 'react';
import type { Page, Article } from '../types';
import { Header } from '../components/Header';
import { DailyRoutineInfographic, GumDiseaseInfographic } from '../components/Infographics';
import { getAllSavedArticleIds, saveArticle, deleteArticle } from '../services/dbService';
import { useAuth } from '../contexts/AuthContext';
import { useLanguage } from '../contexts/LanguageContext';

interface LoginPromptModalProps {
    isOpen: boolean;
    onClose: () => void;
    onNavigate: (page: Page) => void;
}

const LoginPromptModal: React.FC<LoginPromptModalProps> = ({ isOpen, onClose, onNavigate }) => {
    const { t } = useLanguage();
    if (!isOpen) return null;

    const handleAuthNavigation = () => {
        onNavigate('auth');
        onClose();
    };

    return (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm" onClick={onClose}>
            <div className="relative w-full max-w-sm transform-gpu rounded-xl bg-background-light p-6 text-center shadow-2xl transition-all duration-300 dark:bg-background-dark animate-fade-in" onClick={e => e.stopPropagation()}>
                <span className="material-symbols-outlined mb-4 text-5xl text-primary">lock</span>
                <h2 className="text-xl font-bold">{t('learn.login_prompt_title')}</h2>
                <p className="mt-2 text-gray-600 dark:text-gray-400">{t('learn.login_prompt_text')}</p>
                <div className="mt-6 flex flex-col gap-3">
                    <button onClick={handleAuthNavigation} className="w-full rounded-lg bg-primary py-2.5 text-base font-bold text-white hover:bg-primary/90">{t('learn.login_prompt_cta')}</button>
                    <button onClick={onClose} className="w-full rounded-lg bg-gray-200 py-2.5 text-base font-bold text-gray-800 hover:bg-gray-300 dark:bg-gray-700 dark:text-gray-200 dark:hover:bg-gray-600">{t('learn.login_prompt_later')}</button>
                </div>
            </div>
        </div>
    );
};


interface ArticleDetailViewProps {
    article: Article;
    onBack: () => void;
    isSaved: boolean;
    onToggleSave: (id: number) => void;
}

const ArticleDetailView: React.FC<ArticleDetailViewProps> = ({ article, onBack, isSaved, onToggleSave }) => {
    const { t } = useLanguage();
    const contentParts = article.content.split('\n\n');
    const firstParagraph = contentParts[0];
    const restOfContent = contentParts.slice(1);

    const fontSizes = ['sm', 'base', 'lg', 'xl'];
    const [fontSize, setFontSize] = useState('base');

    const handleFontSizeChange = useCallback((direction: 'increase' | 'decrease') => {
        const currentIndex = fontSizes.indexOf(fontSize);
        if (direction === 'increase' && currentIndex < fontSizes.length - 1) {
            setFontSize(fontSizes[currentIndex + 1]);
        } else if (direction === 'decrease' && currentIndex > 0) {
            setFontSize(fontSizes[currentIndex - 1]);
        }
    }, [fontSize, fontSizes]);

    const isMinSize = fontSizes.indexOf(fontSize) === 0;
    const isMaxSize = fontSizes.indexOf(fontSize) === fontSizes.length - 1;

    return (
        <div className="container mx-auto px-4 py-8 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-4xl">
                <button onClick={onBack} className="flex items-center gap-2 text-slate-600 dark:text-slate-400 hover:text-primary dark:hover:text-primary mb-8 font-medium">
                    <span className="material-symbols-outlined">arrow_back</span>
                    {t('learn.back_to_articles')}
                </button>
                <img src={article.image} alt={article.title} className="w-full h-64 md:h-80 object-cover rounded-xl mb-6" />
                <h1 className="text-3xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-4xl mb-4">{article.title}</h1>
                <div className="flex flex-wrap items-center justify-between gap-4 text-sm text-slate-500 dark:text-slate-400 mb-8">
                    <div className="flex items-center gap-4">
                        <span className={`inline-flex items-center gap-1.5 rounded-full bg-green-100 px-2 py-1 text-xs font-medium text-green-800 dark:bg-green-900/50 dark:text-green-300`}>{article.level}</span>
                        <span>·</span>
                        <span>{article.readTime} {t('learn.read_time_suffix')}</span>
                    </div>
                     <div className="flex items-center gap-1">
                        <button onClick={() => onToggleSave(article.id)} className={`p-2 rounded-full hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors ${isSaved ? 'text-primary' : ''}`} aria-label={isSaved ? 'Unsave article' : 'Save article'}>
                            <span className="material-symbols-outlined">{isSaved ? 'bookmark' : 'bookmark_border'}</span>
                        </button>
                        <button onClick={() => handleFontSizeChange('decrease')} disabled={isMinSize} className="p-2 rounded-full disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-200 dark:hover:bg-slate-800" aria-label="Decrease font size">
                            <span className="material-symbols-outlined">text_decrease</span>
                        </button>
                        <button onClick={() => handleFontSizeChange('increase')} disabled={isMaxSize} className="p-2 rounded-full disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-200 dark:hover:bg-slate-800" aria-label="Increase font size">
                            <span className="material-symbols-outlined">text_increase</span>
                        </button>
                    </div>
                </div>
                <div className={`prose dark:prose-invert prose-${fontSize} max-w-none text-slate-700 dark:text-slate-300`}>
                   <p>{firstParagraph}</p>
                   {article.infographic && <article.infographic />}
                   {restOfContent.map((paragraph, index) => {
                     if (paragraph.startsWith('### ')) {
                       return <h3 key={index} className="text-2xl font-bold mt-8 mb-4">{paragraph.replace('### ', '')}</h3>
                     }
                     return <p key={index}>{paragraph}</p>
                   })}
                </div>
            </div>
        </div>
    );
};

interface LearnPageProps {
  onNavigate: (page: Page) => void;
}

const LearnPage: React.FC<LearnPageProps> = ({ onNavigate }) => {
  const { currentUser } = useAuth();
  const { t } = useLanguage();
  const [selectedArticle, setSelectedArticle] = useState<Article | null>(null);
  const [savedArticleIds, setSavedArticleIds] = useState<number[]>([]);
  const [activeTab, setActiveTab] = useState<'all' | 'saved'>('all');
  const [showLoginModal, setShowLoginModal] = useState(false);

  const articles = useMemo<Article[]>(() => [
    { id: 1, title: t('learn.articles.article_1.title'), content: t('learn.articles.article_1.content'), level: "Beginner", readTime: 5, image: "https://lh3.googleusercontent.com/aida-public/AB6AXuArdABUbT4u8U__DPQ0Ojwlqv19Oz-c-WNXEKkQ3xhjGzlhCilDklncoHfQBi6-AB0sJgCq72-XMQ1cnJntnEmr8eZdriadx-mbTztB4XuvQ36b2pzTKzARtjOAHotJ8JUuEMpylZRKQF9jd9dCMjLqOMINoifdIKV0SmogOoUbXyk5uNtmR8ocZ7KolcNJ2OcGrtyQ4cw_uxaAYSKg8uLBdEG33ezcXyWIKoUfqL-RpWhyBX7VTVHPogeaAoQdIh0Doyq-TcIhegvH", infographic: DailyRoutineInfographic },
    { id: 2, title: t('learn.articles.article_2.title'), content: t('learn.articles.article_2.content'), level: "Intermediate", readTime: 8, image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDsR4JHe8oeMXvO1soJkCclxMuhbkmRklB66oZSbnQ_HNev5tHiK7gQdg5TJ2vL3437J55YKICbKyBvMhcwIC3WnwS-QdWjv-pnS1Xkd8Xb3jCBrPjwm2MetjLcqlWhFeyEJLNFes1zOZaA2Pvk6Yr5D6GaGSMX7_ZKDeP7RErNhFXVk9CsGtFUOKEXGfA_wcV6YQxBjFBZct2P2fgcqUTkezN_gFCnGY_5LmH5sz-OMtiInO-UBczW-5hwHjU1suk0cbGRPV6-VjxA", infographic: GumDiseaseInfographic },
    { id: 3, title: t('learn.articles.article_3.title'), content: t('learn.articles.article_3.content'), level: "Beginner", readTime: 7, image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAlP0jq-7N95S-3Xvot1sIt6fgOp5s6mAv8hF3kdnxsy_SZNcauQ2uqrMTP4OQgyezJpYj1u6WI1RRGEKt_CAVQSIIawdzAOAsvMuCws5kPt-wDUp_J_T8oQ3EHA0vF_PuUUBfhzWI2yugm63jVGz99NYuBg_3E6G0b1LFGOUPXoiILDDjbQCs9dbLoVLXmB9JfbKQFFdCv65b3peo2XpEchA4lVu5imN83g-OXjPxZhWKNlZU5D05iXJIttGUDEk3DMauPQCC7xtnQ" },
    { id: 4, title: t('learn.articles.article_4.title'), content: t('learn.articles.article_4.content'), level: "Beginner", readTime: 6, image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDhGRQn-fXeN9U9eIOnvqZGoZS8mgj8-gTjKxI7qGLp_Islhs7UKfDqoRtJroJfw4Tn-ITnQEDYZA50CsClBXgFWmjWJg8FSzBKAl4cTTByybwRw1E7l6cQgzMh4irrf-JwgQDOKAC9L4dnHTP9i7-pK65J1SYaE7QTbuC_2vY_xQApB2JHaxAsr9VssVyUY0BQxPn96C6LVACjrcDmjqbQV_FNAUJzJ6aRBiQkvAkhQNI7-ZSiDbsv3vPV-HSIR8z1IwRk4YfaekG0" },
    { id: 5, title: t('learn.articles.article_5.title'), content: t('learn.articles.article_5.content'), level: "Beginner", readTime: 5, image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBbWBijDDXsw5Z1mEGiENHPVMUZii1WRvWPgXTV_mSCMRFe32q9GUoaHCJLMwutVovis25b-D_iD8J3LkcptAMP34dysjedHAwokVVeSF3qJnprZPK-iiJJTBfkpdeyUHIvAPUl3bYPK48027MCYdGxyOkJxXqSOed84U8v7pPFP7_G0eLF5R89J4N4zNzsVcrfAtNY_Ann9DFWQ3ki8BT9p9XnrbiNCr5HXhL8fWyfNfFOyYhDBtScuYu7IMTQPtnhB_8JwmwQDBhA" }
  ], [t]);

  useEffect(() => {
    if (!currentUser) {
        setSavedArticleIds([]);
        return;
    };
    const loadSavedArticles = async () => {
        try {
            const saved = await getAllSavedArticleIds(currentUser.id);
            setSavedArticleIds(saved);
          
            const initialView = localStorage.getItem('initialLearnView');
            if (initialView === 'saved') {
                setActiveTab('saved');
                localStorage.removeItem('initialLearnView');
            }
        } catch (error) {
            console.error("Failed to load saved articles:", error);
        }
    }
    loadSavedArticles();
  }, [currentUser]);

  const handleToggleSave = async (id: number) => {
    if (!currentUser) {
        setShowLoginModal(true);
        return;
    }
    const isCurrentlySaved = savedArticleIds.includes(id);
    try {
        if (isCurrentlySaved) {
            await deleteArticle(id, currentUser.id);
            setSavedArticleIds(prev => prev.filter(savedId => savedId !== id));
        } else {
            await saveArticle(id, currentUser.id);
            setSavedArticleIds(prev => [...prev, id]);
        }
    } catch (error) {
        console.error("Failed to save articles:", error);
    }
  };

  const getLevelColor = (level: string) => {
    switch(level.toLowerCase()) {
      case 'beginner': return 'green';
      case 'intermediate': return 'yellow';
      default: return 'gray';
    }
  };

  const articlesToShow = activeTab === 'all' 
    ? articles
    : articles.filter(article => savedArticleIds.includes(article.id));
  
  const renderArticleList = () => (
    <div className="container mx-auto px-4 py-8 sm:px-6 lg:px-8">
        <LoginPromptModal isOpen={showLoginModal} onClose={() => setShowLoginModal(false)} onNavigate={onNavigate} />
        <div className="mx-auto max-w-4xl">
        <div className="mb-8 text-center">
            <h1 className="text-4xl font-extrabold tracking-tight text-slate-900 dark:text-white sm:text-5xl">{t('learn.title')}</h1>
            <p className="mt-4 text-lg text-slate-600 dark:text-slate-400">{t('learn.subtitle')}</p>
        </div>
        <div className="relative mb-8">
            <span className="material-symbols-outlined pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500"> search </span>
            <input className="w-full rounded-full border border-slate-300 bg-white py-3 pl-12 pr-4 text-slate-900 placeholder-slate-400 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/50 dark:border-slate-700 dark:bg-slate-900 dark:text-white dark:placeholder-slate-500 dark:focus:border-primary" placeholder={t('learn.search_placeholder')} type="search"/>
        </div>
        <div>
            <div className="mb-6 border-b border-slate-200 dark:border-slate-800">
                <nav className="-mb-px flex space-x-6">
                    <button onClick={() => setActiveTab('all')} className={`whitespace-nowrap border-b-2 py-3 px-1 text-sm font-medium ${activeTab === 'all' ? 'border-primary text-primary' : 'border-transparent text-slate-500 hover:border-slate-300 hover:text-slate-700 dark:text-slate-400 dark:hover:border-slate-700 dark:hover:text-slate-200'}`}>{t('learn.all_articles')}</button>
                    <button onClick={() => setActiveTab('saved')} disabled={!currentUser} title={!currentUser ? "Log in to view saved articles" : ""} className={`whitespace-nowrap border-b-2 py-3 px-1 text-sm font-medium ${activeTab === 'saved' ? 'border-primary text-primary' : 'border-transparent text-slate-500 hover:border-slate-300 hover:text-slate-700 dark:text-slate-400 dark:hover:border-slate-700 dark:hover:text-slate-200'} disabled:opacity-50 disabled:cursor-not-allowed`}>{t('learn.saved_articles')} ({currentUser ? savedArticleIds.length : 0})</button>
                </nav>
            </div>
            <div className="grid gap-8">
            {articlesToShow.length > 0 ? articlesToShow.map((article) => {
                const isSaved = savedArticleIds.includes(article.id);
                return (
                    <div key={article.id} className="group relative flex flex-col gap-4 overflow-hidden rounded-xl border border-slate-200 bg-white transition-shadow duration-300 hover:shadow-lg dark:border-slate-800 dark:bg-slate-900 dark:hover:shadow-primary/10 sm:flex-row">
                        <div onClick={() => setSelectedArticle(article)} className="absolute inset-0 z-0 cursor-pointer"></div>
                        <div className="aspect-video sm:aspect-square sm:w-1/3">
                            <img alt={article.title} className="h-full w-full object-cover" src={article.image} />
                        </div>
                        <div className="flex flex-1 flex-col justify-center p-6 sm:p-4">
                            <h3 className="mb-2 text-xl font-bold text-slate-900 dark:text-white group-hover:text-primary transition-colors">{article.title}</h3>
                            <div className="flex items-center gap-4 text-sm text-slate-500 dark:text-slate-400">
                                <span className={`inline-flex items-center gap-1.5 rounded-full bg-${getLevelColor(article.level)}-100 px-2 py-1 text-xs font-medium text-${getLevelColor(article.level)}-800 dark:bg-${getLevelColor(article.level)}-900/50 dark:text-${getLevelColor(article.level)}-300`}>{article.level}</span>
                                <span>·</span>
                                <span>{article.readTime} {t('learn.read_time_suffix')}</span>
                            </div>
                        </div>
                        <button onClick={(e) => { e.stopPropagation(); handleToggleSave(article.id); }} title={!currentUser ? "Log in to save articles" : (isSaved ? "Unsave article" : "Save article")} className={`absolute top-4 right-4 z-10 p-2 rounded-full bg-white/50 backdrop-blur-sm hover:bg-white/80 dark:bg-slate-800/50 dark:hover:bg-slate-800/80 transition-colors ${isSaved ? 'text-primary' : 'text-slate-600 dark:text-slate-300'}`} aria-label={isSaved ? 'Unsave article' : 'Save article'}>
                            <span className="material-symbols-outlined">{isSaved ? 'bookmark' : 'bookmark_border'}</span>
                        </button>
                    </div>
                )
            }) : (
                <div className="text-center py-16">
                    <p className="text-slate-500 dark:text-slate-400">{t('learn.no_saved_articles')}</p>
                </div>
            )}
            </div>
        </div>
        </div>
    </div>
  );

  return (
    <div className="relative flex min-h-screen w-full flex-col">
      <Header onNavigate={onNavigate} currentPage="learn" />
      <main className="flex-1">
        {selectedArticle ? (
            <ArticleDetailView 
                article={selectedArticle} 
                onBack={() => setSelectedArticle(null)}
                isSaved={savedArticleIds.includes(selectedArticle.id)}
                onToggleSave={handleToggleSave}
            />
        ) : (
            renderArticleList()
        )}
      </main>
    </div>
  );
};

export default LearnPage;