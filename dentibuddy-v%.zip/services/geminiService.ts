import { GoogleGenAI, Chat, GenerateContentResponse, Content } from "@google/genai";
import type { Language, ChatMessage } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const systemInstructions: Record<Language, string> = {
  en: `You are a friendly and helpful AI Oral Health Assistant for South Africa. Your goal is to provide accurate, easy-to-understand information about oral health. You can answer questions about dental hygiene, common oral health problems, prevention tips, and general advice. You can provide information in English, Afrikaans, Xhosa, or Zulu. IMPORTANT: You are not a medical professional. You must not provide medical diagnoses or treatment plans. Always include a disclaimer in your responses advising users to consult a qualified dentist or healthcare professional for any medical concerns, diagnosis, or treatment. Keep your responses concise and helpful.`,
  af: `Jy is 'n vriendelike en hulpvaardige KI Mondgesondheid Assistent vir Suid-Afrika. Jou doel is om akkurate, maklik-verstaanbare inligting oor mondgesondheid te verskaf. Jy kan vrae beantwoord oor tandhigiëne, algemene mondgesondheidsprobleme, voorkoming-wenke en algemene advies. Jy kan inligting in Engels, Afrikaans, Xhosa, of Zulu verskaf. BELANGRIK: Jy is nie 'n mediese beroepspersoon nie. Jy moet nie mediese diagnoses of behandelingsplanne verskaf nie. Sluit altyd 'n vrywaring in jou antwoorde in wat gebruikers aanraai om 'n gekwalifiseerde tandarts of gesondheidswerker te raadpleeg vir enige mediese bekommernisse, diagnose of behandeling. Hou jou antwoorde bondig en nuttig.`,
  xh: `UnguMncedisi we-AI onobuhlobo noncedo wezempilo yomlomo eMzantsi Afrika. Injongo yakho kukubonelela ngolwazi oluchanekileyo, oluqondakala lula malunga nempilo yomlomo. Ungaphendula imibuzo malunga nococeko lwamazinyo, iingxaki eziqhelekileyo zempilo yomlomo, iingcebiso zokuthintela, kunye neengcebiso jikelele. Ungabonelela ngolwazi ngesiNgesi, isiBhulu, isiXhosa, okanye isiZulu. KUBALULEKILE: Awunguye ugqirha. Akufunekanga unike uxilongo lwezonyango okanye izicwangciso zonyango. Soloko ubandakanya isilumkiso kwiimpendulo zakho ucebisa abasebenzisi ukuba babonane nogqirha wamazinyo oqeqeshiweyo okanye umsebenzzi wezempilo ngayo nayiphi na inkxalabo yezonyango, uxilongo, okanye unyango. Gcina iimpendulo zakho zicacile kwaye ziluncedo.`,
  zu: `UnguMsizi we-AI onobungane nosizayo wezempilo yomlomo eNingizimu Afrika. Inhloso yakho ukuhlinzeka ngolwazi olunembile, oluqondakala kalula mayelana nempilo yomlomo. Ungaphendula imibuzo mayelana nenhlanzeko yamazinyo, izinkinga ezivamile zempilo yomlomo, amathiphu okuvimbela, kanye nezeluleko ezijwayelekile. Ungahlinzeka ngolwazi ngesiNgisi, isiBhunu, isiXhosa, noma isiZulu. OKUBALULEKILE: Awuyena udokotela. Akufanele unikeze ukuxilongwa kwezempilo noma amacebo okwelapha. Njalo faka isaziso ezimpendulweni zakho seluleka abasebenzisi ukuthi bathintane nodokotela wamazinyo oqeqeshiwe noma umsebenzi wezempilo nganoma yikuphi ukukhathazeka kwezempilo, ukuxilongwa, noma ukwelashwa. Gcina izimpendulo zakho zifushane futhi zilusizo.`
};

export function createChat(language: Language, history?: ChatMessage[]): Chat {
  const modelHistory: Content[] = (history || [])
    .filter(m => m.text) // Ensure message text is not empty
    .map(message => ({
        role: message.role,
        parts: [{ text: message.text }]
    }));

  return ai.chats.create({
    model: 'gemini-2.5-flash',
    history: modelHistory,
    config: {
      systemInstruction: systemInstructions[language] || systemInstructions['en'],
    },
  });
}

export async function sendMessage(chat: Chat, message: string): Promise<GenerateContentResponse> {
  try {
    const response = await chat.sendMessage({ message });
    return response;
  } catch (error) {
    console.error("Error sending message to Gemini API:", error);
    throw new Error("Failed to get a response from the AI assistant.");
  }
}

const languageNames: Record<Language, string> = {
  en: 'English',
  af: 'Afrikaans',
  xh: 'isiXhosa',
  zu: 'isiZulu'
};

export async function translateText(text: string, sourceLanguage: Language, targetLanguage: Language): Promise<string> {
  if (!text.trim() || sourceLanguage === targetLanguage) return text;
  try {
    const sourceLangName = languageNames[sourceLanguage];
    const targetLangName = languageNames[targetLanguage];
    const prompt = `Translate the following text from ${sourceLangName} to ${targetLangName}. Provide ONLY the translation, with no extra commentary or quotation marks: "${text}"`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    let translated = response.text.trim();
    if ((translated.startsWith('"') && translated.endsWith('"')) || (translated.startsWith("'") && translated.endsWith("'"))) {
      translated = translated.substring(1, translated.length - 1);
    }
    return translated;

  } catch (error) {
    console.error("Error translating text:", error);
    return text; // Fallback to original text if translation fails
  }
}


async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  retries = 3,
  delay = 1000
): Promise<T> {
  try {
    return await fn();
  } catch (error) {
    if (retries > 0) {
      console.warn(`API call failed. Retrying after ${delay}ms... (${retries} retries left)`);
      await new Promise(res => setTimeout(res, delay));
      return retryWithBackoff(fn, retries - 1, delay * 2);
    } else {
      console.error("Max retries reached. Operation failed.");
      throw error;
    }
  }
}

export async function generateImage(prompt: string): Promise<string> {
  const generate = async (): Promise<string> => {
    const response = await ai.models.generateImages({
      model: 'imagen-4.0-generate-001',
      prompt: prompt,
      config: {
        numberOfImages: 1,
        outputMimeType: 'image/png',
        aspectRatio: '1:1',
      },
    });

    if (response.generatedImages && response.generatedImages.length > 0) {
      const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
      return `data:image/png;base64,${base64ImageBytes}`;
    }
    throw new Error("No image was generated by the API.");
  };

  try {
    return await retryWithBackoff(generate);
  } catch (error) {
    console.error("Error generating image after multiple retries. Falling back to a placeholder SVG.", error);
    
    // Fallback for AI assistant avatar
    const placeholderSvg = `
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
          <defs>
             <linearGradient id="aiGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style="stop-color:#38bdf8;stop-opacity:1" />
              <stop offset="100%" style="stop-color:#14b8a6;stop-opacity:1" />
            </linearGradient>
          </defs>
          <circle cx="50" cy="50" r="50" fill="url(#aiGrad)"/>
          <path d="M35 55 Q 50 70 65 55" stroke="white" stroke-width="5" fill="none" stroke-linecap="round"/>
        </svg>
      `;
    
    // Minify and encode the SVG to create a data URL
    const minifiedSvg = placeholderSvg.replace(/(\r\n|\n|\r)/gm, "").replace(/\s+/g, ' ').replace(/> </g, '><').trim();
    const base64Svg = btoa(minifiedSvg);
    return `data:image/svg+xml;base64,${base64Svg}`;
  }
}
