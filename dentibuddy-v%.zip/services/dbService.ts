import type { SymptomLog, CommunityPost, User, ChatSession } from '../types';

const DB_NAME = 'OralHealthDB';
const DB_VERSION = 3; // Bump version for schema change

let db: IDBDatabase | null = null;

const initDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    if (db) {
      return resolve(db);
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = (event) => {
      console.error("IndexedDB error:", request.error);
      reject("IndexedDB error");
    };

    request.onsuccess = (event) => {
      db = request.result;
      resolve(db);
    };

    request.onupgradeneeded = (event) => {
      const dbInstance = (event.target as IDBOpenDBRequest).result;
      
      // User store
      if (!dbInstance.objectStoreNames.contains('users')) {
        const userStore = dbInstance.createObjectStore('users', { keyPath: 'id' });
        userStore.createIndex('email', 'email', { unique: true });
      }
      
      // Symptom Logs store (with userId index)
      if (dbInstance.objectStoreNames.contains('symptomLogs')) {
          dbInstance.deleteObjectStore('symptomLogs');
      }
      const symptomStore = dbInstance.createObjectStore('symptomLogs', { keyPath: 'id' });
      symptomStore.createIndex('userId', 'userId', { unique: false });

      // Saved Articles store (with userId index)
      if (dbInstance.objectStoreNames.contains('savedArticles')) {
          dbInstance.deleteObjectStore('savedArticles');
      }
      const articleStore = dbInstance.createObjectStore('savedArticles', { keyPath: 'id' });
      articleStore.createIndex('userId', 'userId', { unique: false });
      
      // Community Posts (global, no change needed)
      if (!dbInstance.objectStoreNames.contains('communityPosts')) {
        dbInstance.createObjectStore('communityPosts', { keyPath: 'id' });
      }

      // Key-Value store (global, no change needed)
      if (!dbInstance.objectStoreNames.contains('kvStore')) {
        dbInstance.createObjectStore('kvStore', { keyPath: 'key' });
      }

      // Chat History
      if (!dbInstance.objectStoreNames.contains('chatHistory')) {
        const chatStore = dbInstance.createObjectStore('chatHistory', { keyPath: 'id' });
        chatStore.createIndex('userId', 'userId', { unique: false });
      }

      // Remove old profile store
      if (dbInstance.objectStoreNames.contains('profile')) {
          dbInstance.deleteObjectStore('profile');
      }
    };
  });
};

// --- Generic Helpers ---

const getFromIndex = <T>(storeName: string, indexName: string, query: IDBValidKey): Promise<T[]> => {
    return new Promise(async (resolve, reject) => {
        const db = await initDB();
        const transaction = db.transaction(storeName, 'readonly');
        const store = transaction.objectStore(storeName);
        const index = store.index(indexName);
        const request = index.getAll(query);

        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve(request.result);
    });
};

const getAll = <T>(storeName: string): Promise<T[]> => {
    return new Promise(async (resolve, reject) => {
        const db = await initDB();
        const transaction = db.transaction(storeName, 'readonly');
        const store = transaction.objectStore(storeName);
        const request = store.getAll();

        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve(request.result);
    });
};

const getById = <T>(storeName: string, id: string): Promise<T | null> => {
     return new Promise(async (resolve, reject) => {
        const db = await initDB();
        const transaction = db.transaction(storeName, 'readonly');
        const store = transaction.objectStore(storeName);
        const request = store.get(id);

        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve(request.result || null);
    });
}


const save = <T>(storeName: string, item: T): Promise<void> => {
    return new Promise(async (resolve, reject) => {
        const db = await initDB();
        const transaction = db.transaction(storeName, 'readwrite');
        const store = transaction.objectStore(storeName);
        const request = store.put(item);

        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve();
    });
};

const deleteItem = (storeName: string, key: IDBValidKey): Promise<void> => {
    return new Promise(async (resolve, reject) => {
        const db = await initDB();
        const transaction = db.transaction(storeName, 'readwrite');
        const store = transaction.objectStore(storeName);
        const request = store.delete(key);

        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve();
    });
};

// --- KV Store ---
export const getValue = async (key: string): Promise<any> => {
    const db = await initDB();
    return new Promise((resolve, reject) => {
        const transaction = db.transaction('kvStore', 'readonly');
        const store = transaction.objectStore('kvStore');
        const request = store.get(key);

        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve(request.result?.value);
    });
};

export const setValue = async (key: string, value: any): Promise<void> => {
    const db = await initDB();
    return new Promise((resolve, reject) => {
        const transaction = db.transaction('kvStore', 'readwrite');
        const store = transaction.objectStore('kvStore');
        const request = store.put({ key, value });

        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve();
    });
};


// --- User Management ---
export const createUser = (user: User) => save<User>('users', user);
export const getUserById = (id: string) => getById<User>('users', id);
export const getUserByEmail = async (email: string): Promise<User | null> => {
    const users = await getFromIndex<User>('users', 'email', email);
    return users[0] || null;
}

// --- Symptom Logs ---
export const getAllSymptomLogs = (userId: string) => getFromIndex<SymptomLog>('symptomLogs', 'userId', userId);
export const saveSymptomLog = (log: SymptomLog) => save('symptomLogs', log);
export const deleteSymptomLog = (logId: string) => deleteItem('symptomLogs', logId);

// --- Saved Articles ---
interface SavedArticle {
    id: string; // composite key `userId-articleId`
    userId: string;
    articleId: number;
}

export const getAllSavedArticleIds = async (userId: string): Promise<number[]> => {
    const articles = await getFromIndex<SavedArticle>('savedArticles', 'userId', userId);
    return articles.map(a => a.articleId);
}
export const saveArticle = (articleId: number, userId: string) => {
    const item: SavedArticle = { id: `${userId}-${articleId}`, userId, articleId };
    return save('savedArticles', item);
};
export const deleteArticle = (articleId: number, userId: string) => deleteItem('savedArticles', `${userId}-${articleId}`);

// --- Community Posts (Global) ---
export const getAllCommunityPosts = () => getAll<CommunityPost>('communityPosts');
export const saveCommunityPost = (post: CommunityPost) => save('communityPosts', post);
export const deleteCommunityPost = (postId: string) => deleteItem('communityPosts', postId);

// --- Chat History ---
export const getAllChatSessions = (userId: string) => getFromIndex<ChatSession>('chatHistory', 'userId', userId);
export const saveChatSession = (session: ChatSession) => save('chatHistory', session);
export const deleteChatSession = (sessionId: string) => deleteItem('chatHistory', sessionId);